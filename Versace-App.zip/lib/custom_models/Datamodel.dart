
class Datamodel{
  String? uid;
  String? did;
  Datamodel(uid,did);
}