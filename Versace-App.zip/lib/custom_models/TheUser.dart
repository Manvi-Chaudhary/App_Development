class TheUser {
  String? uid;
  TheUser(uid);
}
