package com.example.practiceauthverifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
