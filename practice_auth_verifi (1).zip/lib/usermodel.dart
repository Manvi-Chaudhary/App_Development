class TheUser {
  final String? uid;
  TheUser({required this.uid});
}
